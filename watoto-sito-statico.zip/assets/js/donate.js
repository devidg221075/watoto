(function(){var b=document.getElementById('copy-iban');if(!b)return;var v=document.getElementById('iban-value'),o=b.nextElementSibling;
b.addEventListener('click',function(){var t=v.textContent.replace(/\s+/g,'');function done(){o.textContent=b.getAttribute('data-ok');setTimeout(function(){o.textContent=''},2500)}
if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,function(){})}else{var r=document.createRange();r.selectNodeContents(v);var s=getSelection();s.removeAllRanges();s.addRange(r);try{document.execCommand('copy');done()}catch(e){}}})})();
