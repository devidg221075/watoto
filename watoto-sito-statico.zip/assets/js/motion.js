(function(){if(matchMedia('(prefers-reduced-motion: reduce)').matches||!('IntersectionObserver' in window))return;
var de=document.documentElement,H=innerHeight,items=[];
function add(el,i){if(el.getBoundingClientRect().top<H*.92)return;el.classList.add('rv');if(i)el.classList.add('d'+Math.min(i,4));items.push(el)}
document.querySelectorAll('main > section:not(:first-child)').forEach(function(sec){
var base=sec.classList.contains('wrap')?sec:(sec.querySelector(':scope > .wrap')||sec);
Array.prototype.forEach.call(base.children,function(k){var cs=getComputedStyle(k);
if((cs.display==='grid'||cs.display==='flex')&&k.children.length>1&&k.children.length<=12){Array.prototype.forEach.call(k.children,function(c,i){add(c,i)})}else add(k,0)})});
if(!items.length)return;de.classList.add('js-motion');
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){var t=e.target;io.unobserve(t);t.classList.add('in');setTimeout(function(){t.classList.remove('rv','in','d1','d2','d3','d4')},1200)}})},{threshold:.12,rootMargin:'0px 0px -6% 0px'});
items.forEach(function(e){io.observe(e)})})();
