(function(){var els=document.querySelectorAll('.stats [data-count]');if(!els.length||!('IntersectionObserver' in window)||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
function run(el){var n=+el.getAttribute('data-count'),sup=el.querySelector('sup'),t0=null,d=1200;if(sup)sup=sup.outerHTML;else sup='';
function f(t){if(!t0)t0=t;var k=Math.min((t-t0)/d,1),e=1-Math.pow(1-k,3);el.innerHTML=Math.round(n*e)+sup;if(k<1)requestAnimationFrame(f)}requestAnimationFrame(f)}
var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){io.unobserve(x.target);run(x.target)}})},{threshold:.4});els.forEach(function(e){io.observe(e)})})();
