(function(){
var en=(document.documentElement.lang||'it').indexOf('en')===0;
document.querySelectorAll('.copy-link').forEach(function(b){var o=b.parentNode.querySelector('.share-ok');b.addEventListener('click',function(){var u=b.getAttribute('data-url');function ok(){o.textContent=b.getAttribute('data-ok');setTimeout(function(){o.textContent=''},2500)}
if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(u).then(ok,function(){})}else{var t=document.createElement('textarea');t.value=u;document.body.appendChild(t);t.select();try{document.execCommand('copy');ok()}catch(e){}document.body.removeChild(t)}})});
var grid=document.querySelector('.news-grid');if(!grid)return;
var cards=[].slice.call(grid.querySelectorAll('.news-card'));var years={};
cards.forEach(function(c){var t=c.querySelector('time');var y=t&&(t.getAttribute('datetime')||'').slice(0,4);c.setAttribute('data-year',y||'');if(y)years[y]=1});
var ys=Object.keys(years).sort().reverse();if(ys.length<2)return;
var bar=document.createElement('div');bar.className='news-filter';bar.setAttribute('role','group');bar.setAttribute('aria-label',en?'Filter by year':'Filtra per anno');
var count=document.createElement('p');count.className='news-count';count.setAttribute('role','status');count.setAttribute('aria-live','polite');
function set(y){cards.forEach(function(c){c.hidden=!!y&&c.getAttribute('data-year')!==y});[].forEach.call(bar.children,function(b){b.setAttribute('aria-pressed',String((b.getAttribute('data-y')||'')===(y||'')))});
var n=cards.filter(function(c){return !c.hidden}).length;count.textContent=n+(en?(n===1?' story':' stories'):(n===1?' notizia':' notizie'))}
['' ].concat(ys).forEach(function(y){var b=document.createElement('button');b.type='button';b.setAttribute('data-y',y);b.textContent=y||(en?'All':'Tutte');b.addEventListener('click',function(){set(y)});bar.appendChild(b)});
grid.parentNode.insertBefore(bar,grid);grid.parentNode.insertBefore(count,grid);set('');})();
